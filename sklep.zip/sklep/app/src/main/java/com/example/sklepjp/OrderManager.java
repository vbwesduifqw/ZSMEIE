package com.example.sklepjp;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public class OrderManager {
    private static final String PREFS_NAME = "OrderPrefs";
    private Context context;
    private DatabaseHelper dbHelper;
    private SharedPreferences prefs;

    public OrderManager(Context context) {
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void saveOrder(Order order) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("customer_name", order.getCustomerName());
        values.put("computer", order.getComputer());
        values.put("keyboard", order.getKeyboard());
        values.put("mouse", order.getMouse());
        values.put("monitor", order.getMonitor());
        values.put("total_price", order.getTotalPrice());
        values.put("order_date", order.getOrderDate());

        db.insert(DatabaseHelper.TABLE_ORDERS, null, values);
        db.close();
    }

    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(DatabaseHelper.TABLE_ORDERS,
                null, null, null, null, null, "order_date DESC");

        if (cursor.moveToFirst()) {
            do {
                Order order = new Order();
                order.setId(cursor.getLong(cursor.getColumnIndex("id")));
                order.setCustomerName(cursor.getString(cursor.getColumnIndex("customer_name")));
                order.setComputer(cursor.getString(cursor.getColumnIndex("computer")));
                order.setKeyboard(cursor.getString(cursor.getColumnIndex("keyboard")));
                order.setMouse(cursor.getString(cursor.getColumnIndex("mouse")));
                order.setMonitor(cursor.getString(cursor.getColumnIndex("monitor")));
                order.setTotalPrice(cursor.getDouble(cursor.getColumnIndex("total_price")));
                order.setOrderDate(cursor.getString(cursor.getColumnIndex("order_date")));

                orders.add(order);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return orders;
    }

    public void saveCurrentState() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.apply();
    }

    public void saveState(Bundle outState) {
        outState.putString("customerName", prefs.getString("customerName", ""));
        outState.putString("computer", prefs.getString("computer", ""));
        outState.putString("keyboard", prefs.getString("keyboard", ""));
        outState.putString("mouse", prefs.getString("mouse", ""));
        outState.putString("monitor", prefs.getString("monitor", ""));
        outState.putFloat("totalPrice", prefs.getFloat("totalPrice", 0f));
    }

    public void restoreState(Bundle savedState) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("customerName", savedState.getString("customerName"));
        editor.putString("computer", savedState.getString("computer"));
        editor.putString("keyboard", savedState.getString("keyboard"));
        editor.putString("mouse", savedState.getString("mouse"));
        editor.putString("monitor", savedState.getString("monitor"));
        editor.putFloat("totalPrice", savedState.getFloat("totalPrice"));
        editor.apply();
    }
}