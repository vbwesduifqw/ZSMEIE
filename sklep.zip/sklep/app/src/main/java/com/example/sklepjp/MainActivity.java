package com.example.sklepjp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 123;
    private static final double BASE_PRICE = 2499.0;

    private DatabaseHelper dbHelper;
    private OrderManager orderManager;
    private double totalPrice = 0.0;

    private EditText customerNameInput;
    private Spinner mouseSpinner, keyboardSpinner, webcamSpinner;
    private CheckBox mouseCheckbox, keyboardCheckbox, webcamCheckbox;
    private SeekBar quantitySeekBar;
    private TextView totalPriceText, quantityText;
    private Button saveOrderButton;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        orderManager = new OrderManager(this);

        setupUI();
        setupListeners();
        calculateTotalPrice();

        if (savedInstanceState != null) {
            orderManager.restoreState(savedInstanceState);
        }
    }

    private void setupUI() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Orders - SQLite");

        customerNameInput = findViewById(R.id.customerNameInput);
        mouseSpinner = findViewById(R.id.mouseSpinner);
        keyboardSpinner = findViewById(R.id.keyboardSpinner);
        webcamSpinner = findViewById(R.id.webcamSpinner);
        mouseCheckbox = findViewById(R.id.mouseCheckbox);
        keyboardCheckbox = findViewById(R.id.keyboardCheckbox);
        webcamCheckbox = findViewById(R.id.webcamCheckbox);
        quantitySeekBar = findViewById(R.id.quantitySeekBar);
        totalPriceText = findViewById(R.id.totalPriceText);
        saveOrderButton = findViewById(R.id.saveOrderButton);
        quantityText = findViewById(R.id.quantityText);

        quantitySeekBar.setMax(10);
        quantitySeekBar.setProgress(0);

        setupSpinners();
    }

    private void setupSpinners() {
        String[] mice = {
            "Mysz Dell MS116, cena 35zł",
            "Mysz Gaming Pro, cena 129zł",
            "Mysz Bluetooth, cena 89zł"
        };
        
        String[] keyboards = {
            "Klawiatura TITANUM TK101 USB, cena 19zł",
            "Klawiatura Mechaniczna RGB, cena 299zł",
            "Klawiatura Bezprzewodowa, cena 149zł"
        };
        
        String[] webcams = {
            "Kamera internetowa z mikrofonem DUXO WEBCAM-X13 1080P USB Full HD, cena 89zł",
            "Kamera HD Basic, cena 59zł",
            "Kamera 4K Pro, cena 299zł"
        };

        ArrayAdapter<String> mouseAdapter = new ArrayAdapter<>(this, 
            R.layout.spinner_item,
            mice);
        mouseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mouseSpinner.setAdapter(mouseAdapter);

        ArrayAdapter<String> keyboardAdapter = new ArrayAdapter<>(this, 
            R.layout.spinner_item,
            keyboards);
        keyboardAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        keyboardSpinner.setAdapter(keyboardAdapter);

        ArrayAdapter<String> webcamAdapter = new ArrayAdapter<>(this, 
            R.layout.spinner_item,
            webcams);
        webcamAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        webcamSpinner.setAdapter(webcamAdapter);

        mouseSpinner.setEnabled(false);
        keyboardSpinner.setEnabled(false);
        webcamSpinner.setEnabled(false);
    }

    private void setupListeners() {
        saveOrderButton.setOnClickListener(v -> saveOrder());

        mouseCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mouseSpinner.setEnabled(isChecked);
            calculateTotalPrice();
        });

        keyboardCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            keyboardSpinner.setEnabled(isChecked);
            calculateTotalPrice();
        });

        webcamCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            webcamSpinner.setEnabled(isChecked);
            calculateTotalPrice();
        });

        quantitySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                quantityText.setText(String.valueOf(progress));
                calculateTotalPrice();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculateTotalPrice();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };

        mouseSpinner.setOnItemSelectedListener(spinnerListener);
        keyboardSpinner.setOnItemSelectedListener(spinnerListener);
        webcamSpinner.setOnItemSelectedListener(spinnerListener);
    }

    private void calculateTotalPrice() {
        totalPrice = BASE_PRICE;
        int quantity = quantitySeekBar.getProgress();

        if (mouseCheckbox.isChecked()) {
            String selectedMouse = mouseSpinner.getSelectedItem().toString();
            if (selectedMouse.contains("35zł")) totalPrice += 35.0;
            else if (selectedMouse.contains("129zł")) totalPrice += 129.0;
            else if (selectedMouse.contains("89zł")) totalPrice += 89.0;
        }

        if (keyboardCheckbox.isChecked()) {
            String selectedKeyboard = keyboardSpinner.getSelectedItem().toString();
            if (selectedKeyboard.contains("19zł")) totalPrice += 19.0;
            else if (selectedKeyboard.contains("299zł")) totalPrice += 299.0;
            else if (selectedKeyboard.contains("149zł")) totalPrice += 149.0;
        }

        if (webcamCheckbox.isChecked()) {
            String selectedWebcam = webcamSpinner.getSelectedItem().toString();
            if (selectedWebcam.contains("89zł")) totalPrice += 89.0;
            else if (selectedWebcam.contains("59zł")) totalPrice += 59.0;
            else if (selectedWebcam.contains("299zł")) totalPrice += 299.0;
        }

        if (quantity > 0) {
            totalPrice *= quantity;
        } else {
            totalPrice = 0.0;
        }
        totalPriceText.setText(String.format(Locale.getDefault(), "%.2f zł", totalPrice));
    }

    private void saveOrder() {
        String customerName = customerNameInput.getText().toString().trim();
        if (customerName.isEmpty()) {
            customerNameInput.setError("Wprowadź imię");
            return;
        }
        if (quantitySeekBar.getProgress() == 0) {
            Toast.makeText(this, "Wybierz ilość komputerów", Toast.LENGTH_SHORT).show();
            return;
        }

        Order order = new Order();
        order.setCustomerName(customerName);
        order.setQuantity(quantitySeekBar.getProgress());
        order.setComputer("Intel Core i5 1240 DDR4 8GB 250GB Sata GTX 1050 Ti");

        if (mouseCheckbox.isChecked()) {
            order.setMouse(mouseSpinner.getSelectedItem().toString());
        }
        if (keyboardCheckbox.isChecked()) {
            order.setKeyboard(keyboardSpinner.getSelectedItem().toString());
        }
        if (webcamCheckbox.isChecked()) {
            order.setMonitor(webcamSpinner.getSelectedItem().toString());
        }

        order.setTotalPrice(totalPrice);
        order.setOrderDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));

        try {
            orderManager.saveOrder(order);
            Toast.makeText(this, "Zamówienie zostało zapisane", Toast.LENGTH_SHORT).show();
            clearForm();
        } catch (Exception e) {
            Toast.makeText(this, "Błąd podczas zapisywania zamówienia", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearForm() {
        customerNameInput.setText("");
        mouseCheckbox.setChecked(false);
        keyboardCheckbox.setChecked(false);
        webcamCheckbox.setChecked(false);
        mouseSpinner.setEnabled(false);
        keyboardSpinner.setEnabled(false);
        webcamSpinner.setEnabled(false);
        quantitySeekBar.setProgress(0);
        quantityText.setText("0");
        calculateTotalPrice();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_orders:
                startActivity(new Intent(this, OrderListActivity.class));
                return true;
            case R.id.menu_settings:
                orderManager.saveCurrentState();
                Toast.makeText(this, "Zapisano ustawienia", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_about:
                new AlertDialog.Builder(this)
                        .setTitle("O programie")
                        .setMessage("Aplikacja Sklep Komputerowy\nWersja: 1.0")
                        .setPositiveButton("OK", null)
                        .show();
                return true;
            case R.id.menu_share:
                shareCart();
                return true;
            case R.id.menu_sms:
                sendSMS();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void sendSMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
            return;
        }

        String orderContent = createOrderContent();
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:"));
        intent.putExtra("sms_body", orderContent);
        startActivity(intent);
    }

    private String createOrderContent() {
        StringBuilder content = new StringBuilder();
        content.append("Zamówienie:\n");
        content.append("Klient: ").append(customerNameInput.getText().toString()).append("\n");
        content.append("Komputer: Intel Core i5 1240 DDR4 8GB 250GB Sata GTX 1050 Ti\n");
        content.append("Ilość: ").append(quantitySeekBar.getProgress()).append("\n");

        if (mouseCheckbox.isChecked()) {
            content.append("Mysz: ").append(mouseSpinner.getSelectedItem().toString()).append("\n");
        }
        if (keyboardCheckbox.isChecked()) {
            content.append("Klawiatura: ").append(keyboardSpinner.getSelectedItem().toString()).append("\n");
        }
        if (webcamCheckbox.isChecked()) {
            content.append("Kamera: ").append(webcamSpinner.getSelectedItem().toString()).append("\n");
        }

        content.append("Suma: ").append(String.format(Locale.getDefault(), "%.2f zł", totalPrice));
        return content.toString();
    }

    private void shareCart() {
        String shareContent = createOrderContent();
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent);
        startActivity(Intent.createChooser(shareIntent, "Udostępnij przez"));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        orderManager.saveState(outState);
    }
}